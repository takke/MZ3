#pragma once

/// Kanji-Filter
namespace kf {

/**
 * Kanji-Filter
 */
class kf
{
public:
	kf( FILE* fp_in, FILE* fp_out )
		: infile(fp_in), outfile(fp_out)
	{
		verbose = 0;
		mime = 0;
		text = 0;
		quote = 0;
		showname = 0;
	}

	virtual ~kf()
	{
	}

private:
	int verbose;
	int mime;
	int text;
	int quote;
	int showname;

	char* fname;
	FILE* infile;
	FILE* outfile;

public:
	void error(char *format, ...);

	void tosjis(void);
	void tojis(void);
	void toeuc(void);

private:
	void sjis_to_jis(int *ph, int *pl);
	void jis_to_sjis(int *ph, int *pl);
	void guess(int imax, unsigned char buf[]);
	int dehex(char c);
	int decode_mime(unsigned char *buf);
	int quoted_getc(void);
	int mime_getword(unsigned char *buf, int c);
	int mime_getspaces(unsigned char *buf, int c);
	int mime_getc(void);
	int mygetc(void);
	void myputc(int c);
};

}